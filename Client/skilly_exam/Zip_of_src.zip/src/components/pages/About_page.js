import React from 'react'

export default function AboutPage() {
    return (
        <div>
            <p>This is About Page</p>
        </div>
    )
}