import React from 'react'

export default function ContactPage() {
    return (
        <div>
            <p>This is Contact Page</p>
        </div>
    )
}